##This is project is not currently being maintained

Forked from http://www.eyecon.ro/bootstrap-datepicker/

See documentation [here](http://tarruda.github.com/bootstrap-datetimepicker/).

Visit this [fork](https://github.com/Eonasdan/bootstrap-datetimepicker) for currently maintained copy.
